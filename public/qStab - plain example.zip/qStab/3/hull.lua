-- example program for hull ship
-- (turret controller)

local rsc = peripheral.find('Create_RotationSpeedController')
rsc.setTargetSpeed(0)

local modem = peripheral.find('modem')
modem.closeAll()
modem.open(500)

local stabilizer = dofile('stabilizer.lua')
stabilizer.setup{
    P = 4,
    outputMult = 15,

    forward = vector.new(0,0,-1),

    axis = "y", -- +y for horizontal
    axis_sign = 1,
}

local function receiveFrom(name)
    local _, message
    repeat _, _, _, _, message, _ = os.pullEvent('modem_message')
    until (type(message) == "table") and (message.from == name)
    return message
end

local function fromTable(t)
    return vector.new(t.x, t.y, t.z)
end

-- horizontal stab
local aimingAt = vector.new(-38, -50, -5)
local function main()
    while true do
        local packet = receiveFrom('turret')
        local pos = fromTable(ship.getWorldspacePosition())
        local direction = (aimingAt - pos):normalize()
        local RPM = stabilizer.calculateRPM(packet, direction)
        rsc.setTargetSpeed(RPM)
    end
end

parallel.waitForAll(main)
