-- example program for cannon ship (oscillating turret)

local modem = peripheral.find('modem')

-- sending info for vertical stab
local function sendInfoToTurret()
    while true do
        modem.transmit(500, 0, {from='cannon', quat=ship.getQuaternion()})
        sleep()
    end
end

parallel.waitForAll(sendInfoToTurret)