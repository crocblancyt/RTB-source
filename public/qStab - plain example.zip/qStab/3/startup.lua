-- auto-startup

local name = os.getComputerLabel()

if name then
    term.clear()
    print(name)
    dofile(name..'.lua')
end