
local modem = peripheral.find('modem')

--local radar = peripheral.wrap('top')

---
---on tick:
---  get tanks
---  get CROWS direction
---  auto-lock tank
---  prediction position
---  send target position
---
---



