-- turtle

local modem = peripheral.find('modem')

local engine1 = peripheral.wrap('back')
local engine2 = peripheral.wrap('front')

-- config
local key = 'Hpo4&bw7ssl1jp&knxqw'
local channel = os.getComputerID()

print(channel, type(channel))

modem.closeAll()
modem.open(channel)
dofile('./utils/encryption.lua').wrap(modem, key)

local function refuel()
    peripheral.call('bottom', 'pushFluid', peripheral.getName(engine1))
    peripheral.call('bottom', 'pushFluid', peripheral.getName(engine2))
end

local function fuel_left()
    -- ...
    return 0
end

local function pumping()
    while true do
        refuel()
        modem:send(channel, {name='pump', data={fuel=fuel_left()}})
        sleep()
    end
end

-- auto change fuel tanks
-- send fuel tanks left

parallel.waitForAll(pumping)