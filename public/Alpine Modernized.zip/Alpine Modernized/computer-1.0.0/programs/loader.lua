
local modem = peripheral.find('modem')

local shell_depot = peripheral.wrap('front')
local cartridge_depot = peripheral.wrap('right')

local storage = peripheral.wrap('left')



---
---on modem message:
---  update selected ammo
---  updated firing
---
---on tick:
---  reload ammo & cartridge
---