
local modem = peripheral.find('modem')

-- for display
local fuel_left = 0
local shells_left = {
    ['APDS'] = 0,
    ['HE'] = 0
}
local cartridges_left = 0

local smokes_left = 0

local computer_names = {'tracks', 'turret', 'driver', 'gunner', 'loader', 'pocket.gunner', 'pump', 'smoke'}
local computers_pings = {}

-- config
local fuel_per_second = 1
local key = 'Hpo4&bw7ssl1jp&knxqw'
local channel = os.getComputerID()

-- vars
local gears = {32, 64, 128, 256}
local gear_state = 1
local smoking = false

modem.closeAll()
modem.open(channel)
dofile('./utils/encryption.lua').wrap(modem, key)

function term.writeAt(x,y,str)
    term.setCursorPos(x,y)
    term.write(str)
end

local function display()
    term.clear()

    term.writeAt(3,3, "Gear: "..gears[gear_state])
    term.writeAt(3,4, "Gears: "..textutils.serialise(gears))
    term.writeAt(3,5, "Smoking: "..tostring(smoking))
    
    term.writeAt(3,7, "Smokes left: "..smokes_left)
    term.writeAt(3,8, "APDS left: "..shells_left['APDS'])
    term.writeAt(3,9, "HE left: "..shells_left['HE'])
    --term.writeAt(3,10,"Charges left: "..cartridges_left)
    --term.writeAt(3,11,"Fuel time: "..fuel_left/fuel_per_second)
end

local keys = {}
local prev_keys = {}

local function gearInput()
    -- keybinds
    if keys['e'] and not prev_keys['e'] then
        gear_state = gear_state + 1
    end

    if keys['q'] and not prev_keys['q'] then
        gear_state = gear_state - 1
    end

    -- clamp
    if gear_state < 0 then
        gear_state = 0
    end

    if gear_state > #gears then
        gear_state = #gears
    end
end

local function smokeInput()
    smoking = keys['p']
    
    --[[
    if keys['p'] and not prev_keys['p'] then
        smoking = not smoking
    end
    ]]
end

local function keysUpdated()
    gearInput()
    smokeInput()
    display()
    
    modem:send(channel, {name = 'pocket', data={keys=keys, gear_speed=gears[gear_state], smoking=smoking}})

    prev_keys = keys
end

local function listener()
    while true do
        local event, keycode = os.pullEvent()
        local char = keys.getName(keycode)
        
        if event == "key_up" then
            keys[char] = nil
            keysUpdated()
        elseif event == "key" then
            keys[char] = true
            keysUpdated()
        end
    end
end

local function receiver()
    while true do
        local msg = modem:receive(channel)

        if msg.name == "smoke" then
            smokes_left = msg.data.smokes
        elseif msg.name == 'pump' then
            fuel_left = msg.data.fuel
        end

        display()
        
        sleep()
    end
end

-- APS
-- gear slide
-- damage analysis & indicator
-- hit warning
-- incoming projectiles (direction & warning)
-- ammo toggle
-- smoke control (screen pulse, screen toggle)

parallel.waitForAll(listener, receiver)