
local modem = peripheral.find('modem')

local left = peripheral.wrap('right')
local right = peripheral.wrap('left')

local keys = {}
local gear_speed = 0

-- config
local key = 'Hpo4&bw7ssl1jp&knxqw'
local channel = os.getComputerID()

modem.closeAll()
modem.open(channel)
dofile('./utils/encryption.lua').wrap(modem, key)

local function tracksControl()
    local turning = (keys['a'] and -1 or 0) + (keys['d'] and 1 or 0)
    local moving = (keys['z'] and -1 or 0) + (keys['s'] and 1 or 0)
    
    left.setTargetSpeed((moving + turning) * gear_speed)
    right.setTargetSpeed((moving - turning) * gear_speed)
end

local function receiver()
    while true do
        local msg = modem:receive(channel)

        if msg.name == "pocket" then
            keys = msg.data.keys
            gear_speed = msg.data.gear_speed
            tracksControl()
        end
    end
end

parallel.waitForAll(receiver)
