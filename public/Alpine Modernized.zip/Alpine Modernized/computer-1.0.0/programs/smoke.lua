-- turtle
local modem = peripheral.find('modem')

-- config
local key = 'Hpo4&bw7ssl1jp&knxqw'
local channel = os.getComputerID()

modem.closeAll()
modem.open(channel)
dofile('./utils/encryption.lua').wrap(modem, key)

local function getSmokesScreens()
    local amount = 0
    return amount
end

local smoking = false

local function smoke()
    -- ...
end

local function receiver()
    while true do
        local msg = modem:receive(channel)
        
        if msg.name == "pocket" then
            smoking = msg.data.smoking
        end
    end
end

local function sender_and_smoking()
    while true do
        modem:send(channel, {name='smoke', data={smokes=getSmokesScreens()}})

        if smoking then
            smoke()
        end

        sleep()
    end
end

-- smoke

parallel.waitForAll(receiver, sender_and_smoking)