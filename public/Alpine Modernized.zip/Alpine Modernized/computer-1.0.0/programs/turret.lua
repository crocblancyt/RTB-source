
local modem = peripheral.find('modem')

local left = peripheral.wrap('left')
local right = peripheral.wrap('right')

-- config
local key = 'Hpo4&bw7ssl1jp&knxqw'
local channel = os.getComputerID()

modem.closeAll()
modem.open(channel)
dofile('./utils/encryption.lua').wrap(modem, key)

local keys = {}
local gear_speed = 0

local function turretControl()
    local yawing = (keys['a'] and -1 or 0) + (keys['d'] and 1 or 0)
    local pitching = (keys['z'] and -1 or 0) + (keys['s'] and 1 or 0)
    
    left.setTargetSpeed(yawing * gear_speed / 15)
    right.setTargetSpeed(pitching * gear_speed / 15)
end

local function receiver()
    while true do
        local msg = modem:receive(channel)

        if msg.name == "pocket" then
            keys = msg.data.keys
            gear_speed = msg.data.gear_speed
            turretControl()
        end
    end
end

-- stabilizer

parallel.waitForAll(receiver)