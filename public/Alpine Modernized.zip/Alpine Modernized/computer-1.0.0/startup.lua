-- setup

-- auto-start
local name = os.getComputerLabel()

if name then
    term.clear()
    print(name)
    dofile("programs/"..name..'.lua')
end