local modem = peripheral.find('modem')
local gpu = peripheral.find('tm_gpu')
local radar = peripheral.find("sp_radar")

gpu.refreshSize()
gpu.setSize(64)
gpu.fill()
gpu.sync()

local width, height = gpu.getSize()
local window = gpu.createWindow(1, 1, width, height)

local scanning_paused = false
local scale = 2
local max_range = 10^3

local targets = {}
local target_buttons = {}

local selected_target

local colors = {
    red = 0xFF0000,
    green = 0X00FF00,
    blue = 0x0000FF,

    white = 0xFFFFFF,
    grey = 0x8F8F8F,
    dark_grey = 0x3F3F3F,
    black = 0x000000
}

local function fromRGB(rgb)
    local r = math.floor(rgb[1])
    local g = math.floor(rgb[2])
    local b = math.floor(rgb[3])
    
    return (r * 2^16) + (g * 2^8) + (b * 2^0)
end

function table.find(t, v1)
    for i, v2 in pairs(t) do
        if v1 == v2 then
            return i 
        end
    end
end

local function lerp(a, b, alpha)
    return a + (b - a) * alpha
end

local function distance_from_to(from_x, from_y, to_x, to_y)
    return math.sqrt((to_x - from_x)^2 + (to_y - from_y)^2)
end

local function clamp(min, max, value)
    if value > max then return max end
    if value < min then return min end
    return value
end

local function isOnScreen(x, y)
    if not (1 <= x and x <= width) then return false end
    if not (1 <= y and y <= height) then return false end
    return true
end

local function getId(target)
    if target.is_ship then return target.id end
    if target.is_player then return target.nickname end
    return tostring(target.entity_type)
end

local function getPosition(target)
    local pos = target.pos
    if target.is_ship then return vector.new(pos.x, pos.y, pos.z) end
    return vector.new(pos[1], pos[2], pos[3])
end

local ellipse_x = width * 0.5
local ellipse_y = height * 0.6

local xp_per_x = 0 --1
local yp_per_x = -1/2

local xp_per_y = 0
local yp_per_y = 1

local xp_per_z = -1
local yp_per_z = 0 -- -1/2

local function render3D_Entity(x, y, z, color, isSelected)
    local xp_start = ellipse_x
    local yp_start = ellipse_y

    local to_xp = xp_start + scale * (x * (xp_per_x) + y * (xp_per_y) + z * (xp_per_z))
    local to_yp = yp_start - scale * (x * (yp_per_x) + y * (yp_per_y) + z * (yp_per_z))

    local from_xp = xp_start + scale * (x * (xp_per_x) + z * (xp_per_z))
    local from_yp = yp_start - scale * (x * (yp_per_x) + z * (yp_per_z))
    
    if isOnScreen(to_xp, to_yp) then
        window.lineS(math.floor(from_xp), math.floor(clamp(1, height, from_yp)), math.floor(to_xp), math.floor(clamp(1, height, to_yp)), colors.dark_grey)
    end

    if isOnScreen(to_xp-1, to_yp-1) then
        window.rectangle(math.floor(to_xp)-1, math.floor(to_yp)-1, 3, 3, color)
    end

    if isSelected and isOnScreen(to_xp-2, to_yp-2) then
        window.rectangle(math.floor(to_xp)-2, math.floor(to_yp)-2, 5, 5, colors.red)
    end
    
    return {to_xp-2, to_yp-2}, {3, 3}
end

local function renderEllipse(x, y, height, width)
    for i = 0, math.rad(360), math.rad(0.5) do
        local x_offset = math.cos(i)*width
        local y_offset = math.sin(i)*height

        local grey = ((y_offset / height) + 1) / 2
        local min = 0.1 * 255
        local max = 1 * 255

        local color = fromRGB{
            lerp(min, max, grey),
            lerp(min, max, grey),
            lerp(min, max, grey)
        }

        if isOnScreen(x + x_offset, y + y_offset) then
            window.filledRectangle(
                math.floor(x + x_offset),
                math.floor(y + y_offset),
                1, 1, color)
        end
    end
end

local function onTargetClicked(self)
    selected_target = {
        pos=self.pos, id=self.id, is_player=self.is_player, is_ship=self.is_ship, time=os.clock()
    }

    term.clear()
    print("selected track :")
    print(textutils.serialise(selected_target))
end

local function draw3D()
    for i = 1, 3 do
        local x_size = 10^i
        local z_size = -(10^i)
        local ellipse_width = scale * math.sqrt((x_size * xp_per_x)^2 + (z_size * xp_per_z)^2)
        
        local x_size = 10^i
        local z_size = 10^i
        local ellipse_height = scale * math.sqrt((x_size * yp_per_x)^2 + (z_size * yp_per_z)^2)
        
        renderEllipse(
            ellipse_x,
            ellipse_y,
            ellipse_height,
            ellipse_width
        )
    end

    local from = ship.getWorldspacePosition()
    from = vector.new(from.x, from.y, from.z)
    
    local target_ids = {}

    for i, v in pairs(targets) do
        local target_color = colors.grey
        local target_id = getId(v)
        local to = getPosition(v)
        
        if v.is_ship then
            target_color = colors.blue
        elseif v.is_player then
            target_color = colors.green
        end
        
        local relative_pos = to - from

        local isSelected = false

        if selected_target then
            isSelected = target_id == selected_target.id
        end
        
        local at, size = render3D_Entity(
            relative_pos.x,
            relative_pos.y,
            relative_pos.z,
            target_color,
            isSelected
        )
        
        if not (target_id == -1) then
            local button = target_buttons[target_id]

            if not button then
                button = {
                    x = at[1],
                    y = at[2],
                    
                    x_size = size[1],
                    y_size = size[2]
                }
            
                function button:onCalled()
                    onTargetClicked(self)
                end

                target_buttons[target_id] = button
            end

            
            button.x = at[1]
            button.y = at[2]
                    
            button.x_size = size[1]
            button.y_size = size[2]

            button.id = target_id
            button.is_player = v.is_player
            button.is_ship = v.is_ship
            button.pos = to
        end

        table.insert(target_ids, target_id)
    end
    
    -- cleaning lost tracks
    for id, button in pairs(target_buttons) do
        if not table.find(target_ids, id) then
            target_buttons[id] = nil
        end
    end
end

local buttons = {
    ['pause'] = {
        x = width * 0.80 - 1,
        y = height * 0.95 - 4,

        x_size = width * 0.04 + 1,
        y_size = height * 0.04 + 5,

        onCalled = false
    },

    ['+'] = {
        x = width * 0.85 - 1,
        y = height * 0.95 - 4,

        x_size = width * 0.04 + 1,
        y_size = height * 0.04 + 5,

        onCalled = false
    },

    ['-'] = {
        x = width * 0.90 - 1,
        y = height * 0.95 - 4,
        
        x_size = width * 0.04 + 1,
        y_size = height * 0.04 + 5,
        
        onCalled = false
    }
}

local function draw2D()
    
    -- rectangle (pause)
    window.filledRectangle(
        width * 0.80 - 1, height * 0.95 - 4,
        width * 0.04 + 1, height * 0.04 + 5,
    scanning_paused and colors.red or colors.green)

    -- rectangle (+)
    window.filledRectangle(
        width * 0.85 - 1, height * 0.95 - 4,
        width * 0.04 + 1, height * 0.04 + 5,
    colors.dark_grey)
    
    -- +
    window.drawText(width * 0.85, height * 0.925, "+", colors.white, colors.grey, 1, 1)

    -- rectangle (-)
    window.filledRectangle(
        width * 0.90 - 1, height * 0.95 - 4,
        width * 0.04 + 1, height * 0.04 + 5,
    colors.dark_grey)
    
    -- -
    window.drawText(width * 0.90 , height * 0.925, "-", colors.white, colors.grey, 1, 1)
end

local function render()
    window.fill()
    draw3D()
    draw2D()
    window.sync()
    gpu.sync()
end

local function render_loop()
    while true do
        render()        
        sleep() -- 20fps (every tick / 0.05s)
    end
end

local pause = buttons['pause']
function pause:onCalled(x, y, isShift)
    scanning_paused = not scanning_paused
    render()
end

local plus = buttons['+']
function plus:onCalled(x, y, isShift)
    scale = scale * 1.4
    if scale > 2 then scale = 2 end
    render()
end

local minus = buttons['-']
function minus:onCalled(x, y, isShift)
    scale = scale / 1.4
    if scale < 0.05 then scale = 0.05 end
    render()
end

local function doButtons(buttons, x, y, sneaking, clicks_consumed, max_clicks)
    local clicks_consumed = clicks_consumed or 0
    
    for name, button in pairs(buttons) do
        local isWithinX = (x >= math.floor(button.x)) and (x <= math.floor(button.x + button.x_size))
        local isWithinY = (y >= math.floor(button.y)) and (y <= math.floor(button.y + button.y_size))

        if button.onCalled and isWithinX and isWithinY then
            button:onCalled(x, y, sneaking)
            clicks_consumed = clicks_consumed + 1

            if max_clicks then
                if clicks_consumed >= max_clicks then
                    return clicks_consumed
                end
            end
        end
    end

    return clicks_consumed
end

local function listen_clicks()
    while true do
        local event, side, x, y, sneaking = os.pullEvent("tm_monitor_touch")
        
        local clicks = 0

        clicks = doButtons(target_buttons, x, y, sneaking, clicks, 1)
        clicks = doButtons(buttons, x, y, sneaking, clicks, 1)

        if clicks == 0 then
            selected_target = nil
        end
    end
end

local last_time = os.clock()
local function scanning()
    while true do
        last_time = os.clock()
        
        if not scanning_paused then
            targets = radar.scan(max_range)
        else
            sleep()
        end

        -- selected target auto refresh
        if selected_target then
            for i, v in pairs(targets) do
                local target_id = getId(v)
                local to = getPosition(v)

                if (target_id == selected_target.id) then
                    selected_target.pos = to
                    selected_target.time = os.clock()
                end
            end
        end
        
    end
end

local function sendTargetInfo()
    while true do
        modem.transmit(500, 0, {from='monitor', target=selected_target})
        sleep()
    end
end

parallel.waitForAll(render_loop, listen_clicks, scanning, sendTargetInfo)
