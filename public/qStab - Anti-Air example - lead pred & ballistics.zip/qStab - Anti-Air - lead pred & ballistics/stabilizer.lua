
-- constants
local rad_to_rpm = 1/math.pi/2*60
local asin = math.asin
local atan2 = math.atan2

-- config
local P = 4
local outputMult = 1
local offset = 0
local axis = 'y'
local axis_sign = 1

local function setup(args)
    P = args.P or P
    outputMult = args.outputMult or outputMult
    axis_sign = args.axis_sign or axis_sign
    axis = args.axis or axis
    
    local f = args.forward
    if f then
        offset = -atan2(-f.z, f.x)
    end
end

-- utils
local function short_angle(angle)
    return ((angle + math.pi) % (math.pi*2)) - math.pi
end

local function vector_to_angles(v)
    local yaw = -atan2(-v.z, v.x) - offset
    return vector.new(asin(v.y), short_angle(yaw))
end

local function transformVector(q, v)
    local u = vector.new(q.x, q.y, q.z)
    return u * (u * 2):dot(v) + v*(q.w * q.w - u:dot(u)) + (u * 2 * q.w):cross(v)
end

local function inverseQuat(q) return
    {x=-q.x, y=-q.y, z=-q.z, w=q.w}
end

-- world -> shipyard
local function relative(packet, vec) return transformVector(inverseQuat(packet.quat), vec) end

local function wrapOutput(t, k, f)
    local core = t[k]

    t[k] = function(...)
        return f(core(...))
    end
end

local function fromTable(t) return vector.new(t.x, t.y, t.z) end
wrapOutput(ship, 'getOmega', fromTable)
wrapOutput(ship, 'getWorldspacePosition', fromTable)

-- stabilizer
local previous = {
    omega = vector.new(0,0,0),
    targetAngles = vector.new(0,0,0),
    omegaTarget = vector.new(0,0,0)
}

local function calculateRPM(quaternion, direction) -- has to be called every tick
    local packet = {quat = quaternion}
    packet.relative = relative
    
    -- preparing
    local targetAngles = vector_to_angles(direction)
    local omegaTarget = (previous.targetAngles - targetAngles) / 0.05
    local omega = ship.getOmega()
    
    -- we stabilize for both, input and target
    local local_Omega_Input = packet:relative(omega)
    local local_Torque_Input = packet:relative(previous.omega - omega)

    local local_Omega_Target = packet:relative(omegaTarget)
    local local_Torque_Target = packet:relative(previous.omegaTarget - omegaTarget)

    local local_difference = vector_to_angles(packet:relative(direction))
    
    previous = {
        targetAngles = targetAngles,
        omegaTarget = omegaTarget,
        omega = omega,
    }
    
    -- position, velocity, acceleration
    local RPM = (
        P * -local_difference[axis]
        + ( local_Omega_Target[axis] - axis_sign*local_Omega_Input[axis] )
        - (local_Torque_Target[axis] - axis_sign*local_Torque_Input[axis])
    ) * rad_to_rpm * outputMult
    
    return RPM
end

return {
    setup = setup,
    calculateRPM = calculateRPM
}