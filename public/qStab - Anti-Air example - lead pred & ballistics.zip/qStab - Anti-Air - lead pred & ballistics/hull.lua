-- example program for hull ship
-- (turret controller)

local rsc = peripheral.find('Create_RotationSpeedController')
rsc.setTargetSpeed(0)

local modem = peripheral.find('modem')
modem.closeAll()
modem.open(500)

local stabilizer = dofile('stabilizer.lua')
stabilizer.setup{
    P = 4,
    outputMult = 15,

    forward = vector.new(0,0,-1),

    axis = "y", -- +y for horizontal
    axis_sign = 1,
}

local function fromTable(t)
    return vector.new(t.x, t.y, t.z)
end

local cannon_shipyard_pos = vector.new(-28657664, 129, 12290053) + vector.new(0.5, 0.5, 0.5)

local function transformDirection(q, d)
    local u = vector.new(q.x, q.y, q.z)
    return u * (u * 2):dot(d) + d*(q.w * q.w - u:dot(u)) + (u * 2 * q.w):cross(d)
end

local function transformPosition(quat, pos, from, to)
    local dir = pos - from
    return to + transformDirection(quat, dir)
end

local function getCannonFrom()
    local pos = cannon_shipyard_pos
    
    local world = fromTable(ship.getWorldspacePosition())
    local shipyard = fromTable(ship.getShipyardPosition())
    local quat = ship.getQuaternion()
    
    return transformPosition(quat, pos, shipyard, world)
end

local function receiveFrom(name)
    local _, message
    repeat _, _, _, _, message, _ = os.pullEvent('modem_message')
    until (type(message) == "table") and (message.from == name)
    return message
end

local max_iter = 10
local function calculateLead(from, from_speed, to, to_velocity)
    local ETA = 0 
    
    for i = 1, max_iter do
        local distance = (to + to_velocity * ETA - from):length()
        ETA = distance / from_speed
    end

    return to + to_velocity * ETA
end

local function getVelocity(last_pos, pos, dT)
    return (pos - last_pos) / dT
end

local function calculateDropoff(from, to)
    local distance = (from - to):length()
    return vector.new(0, distance^2 * (1.5/100)^2, 0)
end

-- horizontal stab
local aimingAt = {
    last = nil,
    last_time = os.clock() - 0.05,
    current = nil,
    current_time = os.clock()
}

local function main()
    while true do
        local packet = receiveFrom('turret')
        local direction = vector.new(-1,0,0) -- idle

        if aimingAt.current then
            local from = getCannonFrom()
            local to = aimingAt.current
            
            if aimingAt.last then
                local dT =  aimingAt.current_time - aimingAt.last_time
                
                local velocity = getVelocity(aimingAt.last, aimingAt.current, dT)

                to = calculateLead(from, 150, to, velocity)
            end
            
            to = to + calculateDropoff(from, to)

           direction = (to - from):normalize()
        end
        
        local RPM = stabilizer.calculateRPM(packet.quat, direction)
        rsc.setTargetSpeed(RPM)
    end
end

local function receiveFromMonitor()
    while true do
        local packet = receiveFrom('monitor')

        if packet.target then
            local pos = packet.target.pos
            local time = packet.target.time

            pos = vector.new(pos.x, pos.y, pos.z)
            
            -- noAimingAt or isNewPosition or hasTimedOut
            if (not aimingAt.current) or ((aimingAt.current - pos):length() > 0) then --or ((time - aimingAt.current_time) > 0.2) then
                aimingAt = {
                    last = aimingAt.current,
                    last_time = aimingAt.current_time,
                    current = pos,
                    current_time = time
                }
            end
        else
            aimingAt = {}
        end
    end
end

parallel.waitForAll(main, receiveFromMonitor)
