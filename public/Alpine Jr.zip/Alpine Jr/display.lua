
local width, height = term.getSize()

function math.clamp(min, val, max)
    if val > max then return max end
    if val < min then return min end
    return val
end

local function setPixel(x, y, colorName)
    local x = math.clamp(1, x, width) --left
    local y = math.clamp(1, height-y+1, height) --bottom

    term.setCursorPos(x, y)
    term.setBackgroundColor(colors[colorName])
    term.write(' ')
    term.setBackgroundColor(colors.black)
end

local function drawLine(x1, y1, x2, y2, colorName)
    local x_diff = x2-x1
    local y_diff = y2-y1

    local length = math.sqrt(x_diff^2 + y_diff^2)

    local step = 1/length
    for a = 0, 1+step, step do
        setPixel(x1 + x_diff*a, y1+y_diff*a, colorName)
    end
end

local function angle(vec)
    return math.atan2(vec[2], vec[1])
end

local function vec(angle)
    return math.cos(angle), math.sin(angle)
end

local function drawSquare(square)
    local origin = square.position
    local size = square.size
    local rotation = square.rotation
    local colorName = square.colorName

    local offsets = {
        {size[1], size[2]},
        {size[1], -size[2]},
        {-size[1], -size[2]},
        {-size[1], size[2]}
    }

    for i, offset in pairs(offsets) do
        local angle = angle(offset)
        local len = math.sqrt(offset[1]^2 + offset[2]^2)
        local dx, dy = vec(angle + rotation)
        offsets[i] = {dx*len, dy*len}
    end

    for i = 1, 4 do
        local old_offset = offsets[i-1] or offsets[4]
        local new_offset = offsets[i]

        local old_pos = {
            origin[1] + old_offset[1],
            origin[2] + old_offset[2]
        }

        local new_pos = {
            origin[1] + new_offset[1],
            origin[2] + new_offset[2]
        }

        drawLine(old_pos[1], old_pos[2], new_pos[1], new_pos[2], colorName)
    end
end

local square = {
    position = {width/2, height/2},
    size = {5, 2},
    rotation = 0,
    colorName = 'gray'
}

local turret_angle = 0
local cannon_length = 10

local hull_vel

local function refresh_screen()
    while true do
        term.clear()
        local origin = square.position

        --velocity
        if hull_vel then
            local angle = angle({hull_vel.x, hull_vel.z})
            local v_x, v_z = vec(math.rad(90) -angle)

            local len = math.sqrt(hull_vel.x^2 + hull_vel.z^2) / 3
            drawLine(origin[1], origin[2], origin[1] + v_x*len, origin[2] + v_z*len, 'lime')
        end

        --hull
        drawSquare(square) --hull

        --front indicator
        local dx, dz = vec(square.rotation)
        setPixel(origin[1] - dx*square.size[1], origin[2] - dz*square.size[1], 'lime')

        --cannon
        local t_x, t_z = vec(turret_angle)
        drawLine(origin[1], origin[2], origin[1] -t_x * cannon_length, origin[2] -t_z * cannon_length, 'lightGray')

        
        term.setCursorPos(20, 20)
        term.setBackgroundColor(colors.black)
        term.setTextColor(colors.white)
        -- term.write(string.char(24))

        sleep()
    end
end

local function receive_modem()
    while true do
        local _, _, _, _, packet = os.pullEvent("modem_message")

        if packet.type == 'turret_angle' then
            turret_angle = -packet.payload
        elseif packet.type == 'hull_angle' then
            square.rotation = -packet.payload[1]
            hull_vel = packet.payload[2]
        end
    end
end

return function ()
    parallel.waitForAll(refresh_screen, receive_modem)
end
--drawLine(1, 1, width, height, 'red')