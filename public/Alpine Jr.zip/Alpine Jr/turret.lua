local shoot_side = 'front'
local channel = 15304

local modem = peripheral.find('modem')
modem.closeAll()
modem.open(channel)

local function transmit()
    while true do
        modem.transmit(channel, 0, {
            type = 'turret_angle',
            payload = ship.getYaw()
        })
        sleep()
    end
end

local state = false
local function shoot()
    state = not state
    redstone.setOutput(shoot_side, state)
end

local function receive_keys()
    while true do
        local _, _, _, _, packet = os.pullEvent("modem_message")


        if packet.type == 'keys' then
            local keys = packet.payload

            if keys.f then
                shoot()
            end
        end
    end
end

parallel.waitForAll(transmit, receive_keys)
