-- Pocket computer

local channel = 15304
local modem = peripheral.find('modem')

modem.closeAll()
modem.open(channel)

local keys_down = {}

local function transmit()
    while true do
        modem.transmit(channel, 0, {
            type = 'keys',
            payload = keys_down
        })

        sleep()
    end
end

local function bool_to_nil(bool) -- true = true, false = nil
    if bool then return bool end
end

local function on_key(char, state)
    if state and keys_down[char] then return end --key already present
    keys_down[char] = bool_to_nil(state)
end

local function listener()
    while true do
        local event, button = os.pullEvent()
        
        local key_held = (event == 'key')
        local key_up = (event == 'key_up')
    
        if (key_held or key_up) then
            local char = keys.getName(button)
    
            on_key(char, key_held)
        end
    end
end

local refresh_screen = dofile('display.lua')

parallel.waitForAll(transmit, listener, refresh_screen)

local channel = xxxx
local modem, keys_pressed = peripheral.find('modem'), {}

while true do
    local event, button = os.pullEvent()
    local down, up = (event == 'key'), (event == 'key_up')
    
    if (event or up) then
        keys_pressed[keys.getName(button)] = down
        modem.transmit(channel, 0, keys_pressed)
    end
end