local right_tracks = peripheral.wrap('right')
local left_tracks = peripheral.wrap('left')

local channel = 15304
local tracks_rpm = 256 --181 for perfect turns, 256 for max speed

local modem = peripheral.find('modem')
modem.closeAll()
modem.open(channel)

function math.clamp(min, val, max)
    if val > max then return max end
    if val < min then return min end
    return val
end

local function get_tracks_rpm(drives, max_rpm)
    local length = math.sqrt(drives.forward^2 + drives.right^2)

    if length == 0 then --prevents nan values
        length = 1
    elseif length < 1 then --doesn't convert to unit vector
        length = 1
    end

    local forward = drives.forward / length
    local right = drives.right / length

    return {
        right = math.clamp(-1, forward - right, 1) * max_rpm,
        left = math.clamp(-1, forward + right, 1) * max_rpm
    }
end

local function get_drives(keys)
    local drives = {
        forward = 0,
        right = 0
    }

    if keys.z and not keys.s then
        drives.forward = drives.forward - 1
    end

    if not keys.z and keys.s then
        drives.forward = drives.forward + 1
    end

    if keys.q and not keys.d then
        drives.right = drives.right - 1
    end

    if not keys.q and keys.d then
        drives.right = drives.right + 1
    end

    return drives
end

local function receive_keys()
    while true do
        local _, _, _, _, packet = os.pullEvent("modem_message")

        if packet.type == 'keys' then
            local keys = packet.payload

            local rpms = get_tracks_rpm(get_drives(keys), tracks_rpm)
    
            right_tracks.setTargetSpeed(rpms.right)
            left_tracks.setTargetSpeed(rpms.left)
        end
    end
end

parallel.waitForAll(receive_keys)