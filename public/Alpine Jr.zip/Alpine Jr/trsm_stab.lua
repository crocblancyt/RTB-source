local pitch_rsc = peripheral.wrap('right')
local yaw_rsc = peripheral.wrap('left')

local channel = 15304

local modem = peripheral.find('modem')
modem.closeAll()
modem.open(channel)

local keys = {}

local shift_multiplier = 2.4
local yaw_turning_speed = math.rad(17.5)

local yaw_stab_enabled = true
local enable_toggle = false

local angle
local target_angle = math.rad(90) -- 45

local min = -256
local max = 256
local iclamp = math.rad(0.05)

local p = 2
local i = 10

local d = 1
local accel_d = 0.0983
local no_keys_decel = 1.3

local iterm = 0

function math.clamp(min, val, max)
    if val > max then return max end
    if val < min then return min end
    return val
end

local turn = math.pi
function math.loop_angle(angle) -- -pi to pi
    return ((angle + turn) % (2*turn)) - turn
end

function math.sign(val)
    return (val > 0 and 1) or (val < 0 and -1) or 0
end

local function xor(a, b)
    return (a and not b) or (b and not a)
end

local rad_s_to_rot_min = 1/(2*math.pi)*60 --1 rad/s -> x turn/s -> x turn/min

local last_delta = 0
local function get_rpm(input, target)
    if not input then return 0 end
    
    local delta_time = 0.05 --constant because of CC

    local error = math.loop_angle(input - target)

    iterm = iterm + (error * i * delta_time)
    iterm = math.clamp(-iclamp, iterm, iclamp)

    local delta = ship.getOmega().y
    local accel = (delta - last_delta) / delta_time
    last_delta = delta

    if not xor(keys.q, keys.d) then delta = delta/no_keys_decel end

    local rad_s = (error * p) + (iterm) - (delta*d) - (accel*accel_d)
    
    return math.clamp(min, rad_s * rad_s_to_rot_min * -8, max)
end

function math.round(num)
    return math.floor(num +0.5)
end

local function stabilize()
    while true do
        if yaw_stab_enabled then
            local rpm = get_rpm(angle, target_angle)
            yaw_rsc.setTargetSpeed(math.round(rpm))
        else
            sleep()
        end
    end
end

local function onKeys()
    local delta_time = 0.05
    local speed = yaw_turning_speed

    local turn_yaw = 0
    local turn_pitch = 0

    if keys.leftShift or keys.rightShift then
        speed = speed * shift_multiplier
    end

    if keys.right then
        turn_yaw = turn_yaw + speed
    end
    
    if keys.left then
        turn_yaw = turn_yaw - speed
    end

    if keys.up then
        turn_pitch = turn_pitch + speed
    end
    
    if keys.down then
        turn_pitch = turn_pitch - speed
    end

    enable_toggle = enable_toggle and keys.y
    if not enable_toggle and keys.y then
        yaw_stab_enabled = not yaw_stab_enabled
        enable_toggle = true

        print('switch stab', yaw_stab_enabled)

        if yaw_stab_enabled then
            while not angle do sleep() end
            target_angle = angle
        else
            angle = nil
        end
    end

    if not yaw_stab_enabled then
        yaw_rsc.setTargetSpeed(turn_yaw * 16 * rad_s_to_rot_min)
    else
        target_angle = target_angle + turn_yaw*delta_time
    end

    pitch_rsc.setTargetSpeed(turn_pitch * rad_s_to_rot_min)
end

local function receive_modem()
    while true do
        local _, _, _, _, packet = os.pullEvent("modem_message")

        if packet.type == 'turret_angle' then
            angle = packet.payload
        end

        if packet.type == 'keys' then
            keys = packet.payload
            onKeys()
        end
        
        modem.transmit(channel, 0, {
            type = 'hull_angle',
            payload = {ship.getYaw(), ship.getVelocity()}
        })
    end
end

parallel.waitForAll(stabilize, receive_modem)