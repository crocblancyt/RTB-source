#version 400 compatibility
#define WORLD_MOON
#define vsh
#include "/program/post/motion_blur.glsl"
